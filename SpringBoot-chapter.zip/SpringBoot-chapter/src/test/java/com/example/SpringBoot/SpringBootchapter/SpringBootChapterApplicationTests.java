package com.example.SpringBoot.SpringBootchapter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootChapterApplicationTests {

	@Test
	void contextLoads() {
	}

}
