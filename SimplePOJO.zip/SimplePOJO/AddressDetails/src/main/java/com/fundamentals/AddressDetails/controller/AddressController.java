package com.fundamentals.AddressDetails.controller;

import com.fundamentals.AddressDetails.entity.Address;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class AddressController {

    @GetMapping("/getAddressDetails")
    public Address getAddress(){

        Address address = new Address();
        address.setStreet("123 Main Street");
        address.setCity("Bangalore");

        log.info("Returning Address for the given employeeId");
        return address;
    }

}
