package com.example.SpringBoot.TodoFirst;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoFirstApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoFirstApplication.class, args);
	}

}
