package com.fundamentals.AddressDetails.entity;

import lombok.Data;

@Data
public class Address {

    private String street;
    private String city;

}
