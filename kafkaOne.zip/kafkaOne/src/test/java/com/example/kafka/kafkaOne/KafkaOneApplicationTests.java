package com.example.kafka.kafkaOne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
