package com.example.Spring.Springchapter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringChapterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringChapterApplication.class, args);
	}

}
