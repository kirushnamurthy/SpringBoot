package com.example.JWTspringsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwTspringsecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
