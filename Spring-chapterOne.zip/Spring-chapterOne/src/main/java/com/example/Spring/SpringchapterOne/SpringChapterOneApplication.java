package com.example.Spring.SpringchapterOne;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringChapterOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringChapterOneApplication.class, args);
	}

}
