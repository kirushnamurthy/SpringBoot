package com.fundamentals.EmployeeDetails.entity;

import com.fundamentals.AddressDetails.entity.Address;
import com.fundamentals.VehicleDetails.entity.Vehicle;
import lombok.Data;

@Data

public class Employee {

    private int employeeId;
    private String employeeFirstName;
    private String employeeLastName;

    private Address address;
    private Vehicle vehicle;
}
