package com.example.JmsDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JmsDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JmsDemoApplication.class, args);
	}

}
