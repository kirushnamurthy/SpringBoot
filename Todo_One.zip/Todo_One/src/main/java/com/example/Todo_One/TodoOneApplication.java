package com.example.Todo_One;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoOneApplication.class, args);
	}

}
