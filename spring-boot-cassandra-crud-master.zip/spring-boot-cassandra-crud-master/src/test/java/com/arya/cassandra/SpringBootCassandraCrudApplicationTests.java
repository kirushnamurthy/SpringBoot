package com.arya.cassandra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCassandraCrudApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
