package com.example.SpringBoot.TodoFirst;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoFirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
