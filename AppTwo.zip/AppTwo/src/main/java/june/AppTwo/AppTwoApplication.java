package june.AppTwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppTwoApplication.class, args);
	}

}
