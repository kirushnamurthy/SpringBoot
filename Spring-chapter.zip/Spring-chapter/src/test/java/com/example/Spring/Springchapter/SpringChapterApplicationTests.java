package com.example.Spring.Springchapter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringChapterApplicationTests {

	@Test
	void contextLoads() {
	}

}
