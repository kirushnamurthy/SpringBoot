package com.fundamentals.AddressDetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddressDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
