package com.example.Ss.SpringSecurityBuffer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityBufferApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityBufferApplication.class, args);
	}

}
