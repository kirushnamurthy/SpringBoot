package com.example.project3.projJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjJpaApplication.class, args);
	}

}
