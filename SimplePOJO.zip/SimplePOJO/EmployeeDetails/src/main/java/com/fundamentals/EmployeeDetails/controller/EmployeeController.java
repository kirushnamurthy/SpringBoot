package com.fundamentals.EmployeeDetails.controller;

import com.fundamentals.AddressDetails.entity.Address;
import com.fundamentals.EmployeeDetails.entity.Employee;
import com.fundamentals.VehicleDetails.entity.Vehicle;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

@RestController
@Slf4j
public class EmployeeController {


    /*
    *  get methods
    *  localhost:8080/getEmployeeDetails
    *  localhost:8081/getAddressDetails
    *  localhost:8082/getVehicleDetails
    * */

    @Autowired
    private WebClient.Builder webClient;

    @GetMapping("/getEmployeeDetails")
    public Employee getEmployee(){

        Address address = webClient.build().get()
                .uri("http://localhost:8081/getAddressDetails")
                .retrieve()
                .bodyToMono(Address.class)
                .block();

        Vehicle vehicle = webClient.build().get()
                .uri("http://localhost:8082/getVehicleDetails")
                .retrieve()
                .bodyToMono(Vehicle.class)
                .block();


        Employee employee = new Employee();

        employee.setEmployeeId(1);
        employee.setEmployeeFirstName("Rahul");
        employee.setEmployeeLastName("Sharma");
        employee.setAddress(address);
        employee.setVehicle(vehicle);

        log.info("returning the employee details");
        return employee;
    }



}
