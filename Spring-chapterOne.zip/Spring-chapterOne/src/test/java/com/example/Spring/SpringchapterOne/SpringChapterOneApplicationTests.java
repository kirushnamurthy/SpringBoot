package com.example.Spring.SpringchapterOne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringChapterOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
