package com.example.Todo_One;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
