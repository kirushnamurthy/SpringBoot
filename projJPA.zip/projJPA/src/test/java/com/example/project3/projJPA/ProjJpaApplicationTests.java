package com.example.project3.projJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
