package com.example.securityOne;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityOneApplication.class, args);
	}

}
