package com.example.flywayDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlywayDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
