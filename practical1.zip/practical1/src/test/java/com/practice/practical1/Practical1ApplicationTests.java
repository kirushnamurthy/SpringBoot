package com.practice.practical1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practical1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
