package com.example.Ss.SpringSecurityBuffer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityBufferApplicationTests {

	@Test
	void contextLoads() {
	}

}
