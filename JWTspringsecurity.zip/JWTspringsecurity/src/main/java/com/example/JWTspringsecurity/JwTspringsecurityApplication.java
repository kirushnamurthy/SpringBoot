package com.example.JWTspringsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwTspringsecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwTspringsecurityApplication.class, args);
	}

}
