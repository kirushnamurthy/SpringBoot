package com.example.Error.ErrorEx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErrorExApplicationTests {

	@Test
	void contextLoads() {
	}

}
