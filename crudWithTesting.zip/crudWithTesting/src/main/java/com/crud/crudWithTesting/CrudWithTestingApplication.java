package com.crud.crudWithTesting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudWithTestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudWithTestingApplication.class, args);
	}

}
