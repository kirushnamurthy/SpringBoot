package com.example.Error.ErrorEx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ErrorExApplication {

	public static void main(String[] args) {
		SpringApplication.run(ErrorExApplication.class, args);
	}

}
