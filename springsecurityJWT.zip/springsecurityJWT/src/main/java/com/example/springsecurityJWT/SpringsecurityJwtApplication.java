package com.example.springsecurityJWT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringsecurityJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringsecurityJwtApplication.class, args);
	}

}
