package com.fundamentals.VehicleDetails.entity;

import lombok.Data;

@Data
public class Vehicle {

    private String vehicleNumber;
    private String vehicleBrand;
    private String vehicleColour;

}
