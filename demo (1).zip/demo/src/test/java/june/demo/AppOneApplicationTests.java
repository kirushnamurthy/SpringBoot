package june.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
