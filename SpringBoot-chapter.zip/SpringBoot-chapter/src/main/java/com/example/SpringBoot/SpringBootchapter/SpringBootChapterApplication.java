package com.example.SpringBoot.SpringBootchapter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootChapterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootChapterApplication.class, args);
	}

}
